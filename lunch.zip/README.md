# lunchweb

Simple lunch website for informatics

**Sql schema:**
https://drawsql.app/lunchapp/diagrams/lunchapp

**TODO:**

-   Dashboard: page and functionaltity
-   Submit
